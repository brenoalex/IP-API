from django.contrib import admin

from IPApi.IPAdresses.models import IPAdress

admin.site.register(IPAdress)
# Register your models here.
