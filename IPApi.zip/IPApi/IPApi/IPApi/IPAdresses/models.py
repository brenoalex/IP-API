from django.db import models
from django.conf import settings


class IPAdress(models.Model):
    ip = models.CharField(max_length=30)
    city = models.CharField(max_length=30)
    def __str__(self):
        return self.ip
