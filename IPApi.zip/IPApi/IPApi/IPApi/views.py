from telnetlib import IP
from django.shortcuts import render
import requests
from django.http import HttpResponse
from IPApi.IPAdresses.models import IPAdress

def homepage(request):
    return render(request, 'homepage.html')

def results(request):
    ipv4= request.POST.get('IPV4')
    response = requests.get('http://ip-api.com/json/' + ipv4)
    geodata = response.json()
    #b = IPAdress(ip=geodata['query'], city=geodata['city'])
    ip = geodata['query']
    city = geodata['city']
    adress = IPAdress.objects.create(ip=ip, city=city)
    #b = IPAdress(ip='blable', city='anyone')
    adress.save()

    return render(request, 'results.html', {
        'query': geodata['query'],
        'status': geodata['status'],
        'city': geodata['city']
    }) 

def history(request):

    all_objects = IPAdress.objects.all()
    context= {'all_objects': all_objects}

    print(context);
        
    return render(request, 'history.html', context)

